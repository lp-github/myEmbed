

#include "serial.h"

#define DIS_        0x11
u8 code t_display[]={                      
//   0    1    2    3    4    5    6    7    8    9    A    B    C    D    E    F
    0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71,
//black  -     H    J    K    L    N    o   P    U     t    G    Q    r   M    y
    0x00,0x40,0x76,0x1E,0x70,0x38,0x37,0x5C,0x73,0x3E,0x78,0x3d,0x67,0x50,0x37,0x6e,
    0xBF,0x86,0xDB,0xCF,0xE6,0xED,0xFD,0x87,0xFF,0xEF,0x46};    //0. 1. 2. 3. 4. 5. 6. 7. 8. 9. -1

u8 code T_COM[]={0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
u8 msg;
sbit    P_HC595_SER   = P4^0;   //pin 14    SER     data input
sbit    P_HC595_RCLK  = P5^4;   //pin 12    RCLk    store (latch) clock
sbit    P_HC595_SRCLK = P4^3;   //pin 11    SRCLK   Shift data clock

u8  LED8[8];        
u8  display_index;  
u8 	i;
#define Timer0_Reload   (65536UL - 10000)       //Timer 0 中断频率, 1000次/秒

void recieveData(u8 rc_data){
		if(rc_data <= '9' && rc_data >= '0')
		{
			LED8[0] = LED8[1];
			LED8[1] = LED8[2];
		  	LED8[2] = LED8[3];
			LED8[3] = LED8[4];
			LED8[4] = LED8[5];
		  	LED8[5] = LED8[6];
			LED8[6] = LED8[7];
			switch(rc_data){
			case '0':
			 	LED8[7] = 0;
				break;
			case '1':
			 	LED8[7] = 1;
				break;
			case '2':
			 	LED8[7] = 2;
				break;
			case '3':
			 	LED8[7] = 3;
				break;
			case '4':
			 	LED8[7] = 4;
				break;
			case '5':
			 	LED8[7] = 5;
				break;
			case '6':
			 	LED8[7] = 6;
				break;
			case '7':
			 	LED8[7] = 7;
				break;
			case '8':
			 	LED8[7] = 8;
				break;
			case '9':
			 	LED8[7] = 9;
				break;
            default:
			 	LED8[7] = DIS_;
				break;                
			}
		}else{
			return;
		}
}

/**************** 向HC595发送一个字节函数 ******************/
void Send_595(u8 dat)
{       
    u8  i;
    for(i=0; i<8; i++)
    {
        dat <<= 1;
        P_HC595_SER   = CY;
        P_HC595_SRCLK = 1;
        P_HC595_SRCLK = 0;
    }
}

/********************** 显示扫描函数 ************************/
void DisplayScan(void)
{   
    Send_595(~T_COM[display_index]);               
    Send_595(t_display[LED8[display_index]]);  
    P_HC595_RCLK = 1;
    P_HC595_RCLK = 0;                          
    if(++display_index >= 8)    display_index = 0;  
}

/********************** Timer0 1ms中断函数 ************************/
void timer1 (void) interrupt 1
{
    DisplayScan();  //1ms扫描显示一位
}



void main(void) {
    AUXR = 0x80;    
    TMOD = 0x00;

    TH0 = (u8)(Timer0_Reload / 256);
    TL0 = (u8)(Timer0_Reload % 256);
    ET0 = 1;    //Timer0 interrupt enable
    TR0 = 1;    //Timer0 run

    for(i = 0; i < 8; i++)
        LED8[i] = 0x10;
    serial_init();
    while(1);
}

void UART1_int (void) interrupt 4
{
    if(RI)
    {	   
		
        msg = SBUF;
		recieveData(msg);
        
		RI = 0;
    }

    if(TI)
    {
        TI = 0;
        
    }
}
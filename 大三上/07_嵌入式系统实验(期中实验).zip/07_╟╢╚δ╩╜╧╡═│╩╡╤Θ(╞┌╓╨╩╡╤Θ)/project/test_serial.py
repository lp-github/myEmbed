﻿# coding=utf-8
import platform
import sys
import serial
import threading


OS_NAME = platform.system()
OS_IS_WINDOWS = OS_NAME == 'Windows'
OS_IS_LINUX = OS_NAME in ['Linux', 'Darwin']
assert OS_IS_WINDOWS or OS_IS_LINUX,\
    Exception('Unsupported Operator System: {}'.format(OS_NAME))

if sys.version_info[0] >= 3:
    raw_input = input

PORT = '/dev/ttyUSB0' if OS_IS_LINUX else 'COM5'
BAUDRATE = 115200
TIMEOUT = 0.5

# 读取串口
SERIAL = serial.Serial(PORT, BAUDRATE, timeout=TIMEOUT)


while 1:
    msg = raw_input("Please input a char:\n")
    SERIAL.write(msg.encode('utf-8'))
    